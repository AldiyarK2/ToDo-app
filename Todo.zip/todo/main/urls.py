from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name = 'login'),
    path('list/', views.taskList, name='content'),
    path('insert_todo/',views.insert_todo_item, name='insert_todo_item'),
    path('delete_todo/<int:todo_idss>',views.delete_todo_item, name='delete_todo_item')
]