from email import message
from bcrypt import re
from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponse
from numpy import meshgrid
from .models import Todo
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = User.objects.create_user(username=username, password=password)
        user.save()
        messages.info(request, 'User created')
        return redirect('/main/list/')
    else:
        return render(request,'register.html')

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/main/list/')
        else:
            print('invalid login or password')
    else:
        return render(request,'login.html')



def taskList(request):
    tasks = { 'todoList' : Todo.objects.all()}
    return render(request, 'main/todoList.html', tasks)

def insert_todo_item(request:HttpRequest):
    todo = Todo(content = request.POST['content'])
    todo.save()
    return redirect('/main/list/')

def delete_todo_item(request, todo_id):
    todo_to_delete = Todo.objects.get(id=todo_id)
    todo_to_delete.delete()
    return redirect('/main/list/')
